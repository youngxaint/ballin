import {
  GoogleGenAI,
  HarmBlockThreshold,
  HarmCategory,
  type Content,
  type GenerateContentConfig,
} from "@google/genai";
import { ENZO_SYSTEM_PROMPT } from "./prompt.js";
import {
  EMERGENCY_RESPONSE,
  SELF_HARM_RESPONSE,
  detectSafetyFlag,
  type SafetyFlag,
} from "./safety.js";

export interface EnzoOptions {
  apiKey: string;
  /** Gemini model id. Defaults to ENZO_MODEL env or gemini-2.5-flash. */
  model?: string;
  temperature?: number;
  /** Max user/assistant exchanges kept per session. Default 20. */
  maxHistoryTurns?: number;
  /** Override or extend the built-in system prompt. */
  systemPrompt?: string;
}

export interface EnzoReply {
  text: string;
  /** Set when Enzo short-circuited with a safety response instead of calling Gemini. */
  safetyFlag: SafetyFlag;
}

export class EnzoError extends Error {
  constructor(message: string, public readonly cause?: unknown) {
    super(message);
    this.name = "EnzoError";
  }
}

const FALLBACK_BLOCKED =
  "I wasn't able to answer that one. Could you rephrase, or share a bit more detail? " +
  "For anything urgent, please contact a clinician or your local emergency number.";

export class Enzo {
  private readonly ai: GoogleGenAI;
  private readonly model: string;
  private readonly maxContents: number;
  private readonly config: GenerateContentConfig;
  private readonly sessions = new Map<string, Content[]>();

  constructor(opts: EnzoOptions) {
    if (!opts.apiKey) throw new EnzoError("A Gemini API key is required.");
    this.ai = new GoogleGenAI({ apiKey: opts.apiKey });
    this.model = opts.model ?? process.env.ENZO_MODEL ?? "gemini-2.5-flash";
    this.maxContents = (opts.maxHistoryTurns ?? 20) * 2;
    this.config = {
      systemInstruction: opts.systemPrompt ?? ENZO_SYSTEM_PROMPT,
      temperature: opts.temperature ?? 0.4,
      maxOutputTokens: 1024,
      // Health topics can trip default filters; only block high-severity content.
      safetySettings: [
        HarmCategory.HARM_CATEGORY_DANGEROUS_CONTENT,
        HarmCategory.HARM_CATEGORY_HARASSMENT,
        HarmCategory.HARM_CATEGORY_HATE_SPEECH,
        HarmCategory.HARM_CATEGORY_SEXUALLY_EXPLICIT,
      ].map((category) => ({
        category,
        threshold: HarmBlockThreshold.BLOCK_ONLY_HIGH,
      })),
    };
  }

  /** Send a message and get the full reply. */
  async chat(sessionId: string, message: string): Promise<EnzoReply> {
    const flag = this.preCheck(sessionId, message);
    if (flag) return { text: this.safetyText(flag), safetyFlag: flag };

    const history = this.history(sessionId);
    try {
      const res = await this.ai.models.generateContent({
        model: this.model,
        contents: history,
        config: this.config,
      });
      const text = res.text?.trim() || FALLBACK_BLOCKED;
      this.push(sessionId, "model", text);
      return { text, safetyFlag: null };
    } catch (err) {
      this.rollbackLastUserTurn(sessionId);
      throw new EnzoError("Gemini request failed.", err);
    }
  }

  /** Stream a reply chunk by chunk. */
  async *chatStream(
    sessionId: string,
    message: string,
  ): AsyncGenerator<string, EnzoReply, void> {
    const flag = this.preCheck(sessionId, message);
    if (flag) {
      const text = this.safetyText(flag);
      yield text;
      return { text, safetyFlag: flag };
    }

    const history = this.history(sessionId);
    let full = "";
    try {
      const stream = await this.ai.models.generateContentStream({
        model: this.model,
        contents: history,
        config: this.config,
      });
      for await (const chunk of stream) {
        const piece = chunk.text;
        if (piece) {
          full += piece;
          yield piece;
        }
      }
    } catch (err) {
      this.rollbackLastUserTurn(sessionId);
      throw new EnzoError("Gemini stream failed.", err);
    }

    if (!full.trim()) {
      full = FALLBACK_BLOCKED;
      yield full;
    }
    this.push(sessionId, "model", full.trim());
    return { text: full.trim(), safetyFlag: null };
  }

  reset(sessionId: string): void {
    this.sessions.delete(sessionId);
  }

  // ---- internals ----

  /** Records the user turn; returns a safety flag if Enzo should short-circuit. */
  private preCheck(sessionId: string, message: string): SafetyFlag {
    const text = message.trim();
    if (!text) throw new EnzoError("Message is empty.");
    this.push(sessionId, "user", text);
    const flag = detectSafetyFlag(text);
    if (flag) this.push(sessionId, "model", this.safetyText(flag));
    return flag;
  }

  private safetyText(flag: Exclude<SafetyFlag, null>): string {
    return flag === "self_harm" ? SELF_HARM_RESPONSE : EMERGENCY_RESPONSE;
  }

  private history(sessionId: string): Content[] {
    return this.sessions.get(sessionId) ?? [];
  }

  private push(sessionId: string, role: "user" | "model", text: string): void {
    const h = this.history(sessionId);
    h.push({ role, parts: [{ text }] });
    // Trim oldest turns, keeping the conversation starting on a user turn.
    while (h.length > this.maxContents) h.shift();
    while (h.length && h[0].role !== "user") h.shift();
    this.sessions.set(sessionId, h);
  }

  private rollbackLastUserTurn(sessionId: string): void {
    const h = this.history(sessionId);
    if (h.at(-1)?.role === "user") h.pop();
  }
}
